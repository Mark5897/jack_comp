/**
 * Handles the kind of data type.
 * @author vincentii
 * @version 1.0
 */
public enum Kind {
    FIELD,
    STATIC,
    LOCAL,
    ARGUMENT
}